# Base Code
# from flask import Flask, request, jsonify
# from transformers import pipeline
# from flask_cors import CORS

# # Initialize the Flask app
# app = Flask(__name__)
# CORS(app)  # Enable CORS for cross-origin requests

# # Load the question-answering pipeline
# qa_pipeline = pipeline("question-answering")

# @app.route('/predict', methods=['POST'])
# def predict():
#     # Parse incoming JSON request
#     data = request.get_json()
#     context = data.get('context', '')
#     question = data.get('question', '')

#     # Validate input
#     if not context or not question:
#         return jsonify({"error": "Context and question are required"}), 400

#     try:
#         # Generate the answer using the QA pipeline
#         result = qa_pipeline({"context": context, "question": question})
#         return jsonify({"answer": result['answer']})
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# if __name__ == "__main__":
#     app.run(debug=True)


# SEcond try only for english
# from flask import Flask, request, jsonify
# from transformers import pipeline
# from flask_cors import CORS

# # Initialize the Flask app
# app = Flask(__name__)
# CORS(app)  # Enable CORS for cross-origin requests

# # Load the question-answering pipeline with the English model
# qa_pipeline = pipeline("question-answering", model="bert-large-uncased-whole-word-masking-finetuned-squad")

# @app.route('/predict', methods=['POST'])
# def predict():
#     # Parse incoming JSON request
#     data = request.get_json()
#     context = data.get('context', '')
#     question = data.get('question', '')

#     # Validate input
#     if not context or not question:
#         return jsonify({"error": "Context and question are required"}), 400

#     try:
#         # Generate the answer using the QA pipeline
#         result = qa_pipeline({"context": context, "question": question})
#         return jsonify({"answer": result['answer']})
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# if __name__ == "__main__":
#     app.run(debug=True)


# Third try with both models as well as language detection

from flask import Flask, request, jsonify
from transformers import pipeline
from flask_cors import CORS
from langdetect import detect

# Initialize the Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for cross-origin requests

# Load the question-answering pipelines for English and Spanish
qa_pipeline_english = pipeline("question-answering", model="bert-large-uncased-whole-word-masking-finetuned-squad")
qa_pipeline_spanish = pipeline("question-answering", model="deepset/xlm-roberta-large-squad2")

@app.route('/predict', methods=['POST'])
def predict():
    # Parse incoming JSON request
    data = request.get_json()
    context = data.get('context', '')
    question = data.get('question', '')

    # Validate input
    if not context or not question:
        return jsonify({"error": "Context and question are required"}), 400

    try:
        # Detect the language automatically
        language = detect(context)

        # Determine which pipeline to use based on detected language
        if language == 'es':  # Spanish
            result = qa_pipeline_spanish({"context": context, "question": question})
        else:  # Default to English
            result = qa_pipeline_english({"context": context, "question": question})
        
        return jsonify({"answer": result['answer'], "language_detected": language})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
